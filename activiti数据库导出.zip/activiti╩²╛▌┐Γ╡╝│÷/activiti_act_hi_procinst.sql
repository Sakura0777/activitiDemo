-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: activiti
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `act_hi_procinst`
--

DROP TABLE IF EXISTS `act_hi_procinst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `act_hi_procinst` (
  `ID_` varchar(64) COLLATE utf8mb3_bin NOT NULL,
  `PROC_INST_ID_` varchar(64) COLLATE utf8mb3_bin NOT NULL,
  `BUSINESS_KEY_` varchar(255) COLLATE utf8mb3_bin DEFAULT NULL,
  `PROC_DEF_ID_` varchar(64) COLLATE utf8mb3_bin NOT NULL,
  `START_TIME_` datetime(3) NOT NULL,
  `END_TIME_` datetime(3) DEFAULT NULL,
  `DURATION_` bigint DEFAULT NULL,
  `START_USER_ID_` varchar(255) COLLATE utf8mb3_bin DEFAULT NULL,
  `START_ACT_ID_` varchar(255) COLLATE utf8mb3_bin DEFAULT NULL,
  `END_ACT_ID_` varchar(255) COLLATE utf8mb3_bin DEFAULT NULL,
  `SUPER_PROCESS_INSTANCE_ID_` varchar(64) COLLATE utf8mb3_bin DEFAULT NULL,
  `DELETE_REASON_` varchar(4000) COLLATE utf8mb3_bin DEFAULT NULL,
  `TENANT_ID_` varchar(255) COLLATE utf8mb3_bin DEFAULT '',
  `NAME_` varchar(255) COLLATE utf8mb3_bin DEFAULT NULL,
  PRIMARY KEY (`ID_`),
  UNIQUE KEY `PROC_INST_ID_` (`PROC_INST_ID_`),
  KEY `ACT_IDX_HI_PRO_INST_END` (`END_TIME_`),
  KEY `ACT_IDX_HI_PRO_I_BUSKEY` (`BUSINESS_KEY_`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `act_hi_procinst`
--

LOCK TABLES `act_hi_procinst` WRITE;
/*!40000 ALTER TABLE `act_hi_procinst` DISABLE KEYS */;
INSERT INTO `act_hi_procinst` VALUES ('1000120','1000120',NULL,'leaveApplication:1:1035004','2025-05-29 10:17:59.785','2025-05-29 10:19:21.427',81642,'拉克丝','sid-ce4f720e-6e45-4198-b89c-8b2c7406334f','sid-0dfbdafb-ddca-4546-a912-ad3ee98e0c6e',NULL,NULL,'',NULL),('1000138','1000138',NULL,'businessTravelProcessParallel:1:1032504','2025-05-29 10:18:13.712','2025-05-29 10:19:14.886',61174,'拉克丝','sid-97e258b2-54c0-4514-8d0a-14fcea53b220','sid-c6c5cae9-c770-4add-a8c3-9106ff750ef7',NULL,'terminate end event (sid-c6c5cae9-c770-4add-a8c3-9106ff750ef7)','',NULL),('1000174','1000174',NULL,'leaveApplication:1:1035004','2025-05-29 10:20:07.617','2025-05-29 10:21:17.580',69963,'拉克丝','sid-ce4f720e-6e45-4198-b89c-8b2c7406334f','sid-b86c1b3b-752c-40c7-9fce-0983d5ffd754',NULL,NULL,'',NULL),('1000192','1000192',NULL,'businessTravelProcessParallel:1:1032504','2025-05-29 10:20:21.466','2025-05-29 10:20:38.478',17012,'拉克丝','sid-97e258b2-54c0-4514-8d0a-14fcea53b220','sid-c6c5cae9-c770-4add-a8c3-9106ff750ef7',NULL,'terminate end event (sid-c6c5cae9-c770-4add-a8c3-9106ff750ef7)','',NULL),('1000225','1000225',NULL,'businessTravelProcessParallel:1:1032504','2025-05-29 10:21:56.472','2025-05-29 10:22:53.454',56982,'拉克丝','sid-97e258b2-54c0-4514-8d0a-14fcea53b220','sid-7bb38c4d-5666-4618-b0c5-c4a673045dee',NULL,NULL,'',NULL),('1000259','1000259',NULL,'businessTravelProcessParallel:1:1032504','2025-05-29 10:23:27.360',NULL,NULL,'拉克丝','sid-97e258b2-54c0-4514-8d0a-14fcea53b220',NULL,NULL,NULL,'',NULL),('187502','187502',NULL,'leaveApplication:1:185004','2025-05-12 10:07:06.497','2025-05-12 10:07:21.961',15464,NULL,'sid-ce4f720e-6e45-4198-b89c-8b2c7406334f','sid-0dfbdafb-ddca-4546-a912-ad3ee98e0c6e',NULL,NULL,'',NULL),('197502','197502',NULL,'leaveApplication:1:185004','2025-05-12 10:21:49.444','2025-05-12 10:22:08.172',18728,NULL,'sid-ce4f720e-6e45-4198-b89c-8b2c7406334f','sid-0dfbdafb-ddca-4546-a912-ad3ee98e0c6e',NULL,NULL,'',NULL),('207502','207502',NULL,'leaveApplication:1:185004','2025-05-12 10:29:02.847','2025-05-12 10:29:26.206',23359,NULL,'sid-ce4f720e-6e45-4198-b89c-8b2c7406334f','sid-0dfbdafb-ddca-4546-a912-ad3ee98e0c6e',NULL,NULL,'',NULL);
/*!40000 ALTER TABLE `act_hi_procinst` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-29 11:10:56
