-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: activiti
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `userId` char(36) NOT NULL,
  `userName` varchar(45) NOT NULL,
  `userRole` char(1) NOT NULL,
  `password` varchar(64) DEFAULT NULL,
  `department` varchar(45) DEFAULT NULL,
  `salt` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `userId_UNIQUE` (`userId`),
  UNIQUE KEY `userName_UNIQUE` (`userName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('80e70d33-64b7-4752-8bba-1e3d8bc82469','盖伦','2','96b04544f7aa4117382a9b2fd18ee8a41d6798fb3103315f84523951bd8dc501','development','7960a0d3831cbebc9082802e224781c0'),('86801d56-dd87-42ac-878a-89dd01fc21f9','佐伊','1','6e3cd2dce85c87f0aab38390e4d03bb0be23c5a5f0c698d843ff3bcbabeae9ed','development','1c1c56cc0ffd6a89b5d849be1d8c4301'),('967154aa-08b0-4dcc-b2f8-b065b586f031','黑默丁格','3','f1f9138ee2a8d0d911608d0daf3521b535f076dfa4a49f168c82cb9c31b7995f','admin','c727bd856b056129c423924810700b83'),('9e23debf-5b96-4dce-abf7-40866c2c32ad','墨菲特','0','5b72433d70d30bde50618195990afa0bf8aa9e8e76cacbb1b3b5433c42823545','development','fec9f42fc0ecaa4365a4ec0f5dbb5f0a'),('a1bac0e0-0d91-4a37-aa4b-146b563c85e9','金克丝','0','51861b914c4785f086dc68cd502e574df32cee1f9351600cdf3586fb1e997ace','development','bbf50916a23aa3111f6ba2b046d057aa'),('be41024e-167b-477c-87b4-35d0622a6ca9','崔丝塔娜','0','9a007d5811082adaf004aacdfd2d47375a6141075a1b85009b18be8d1569e3cc','sale','bb9617b970be72f41ce4f9e904b0be91'),('c3505a1e-afea-4112-b43e-ac1c30a0e4db','拉克丝','0','e3089e2b64177bc5d469d2b481fcbc3be51348cf1b22a9cffb60339ac446e39a','development','3651d2ca6f0a0b70c418947505bab8a4');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-29 11:10:58
